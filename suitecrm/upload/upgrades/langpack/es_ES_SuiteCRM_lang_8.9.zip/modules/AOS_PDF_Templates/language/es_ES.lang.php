<?php
/**
 *
 * SugarCRM Community Edition is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004-2013 SugarCRM Inc.
 *
 * SuiteCRM is an extension to SugarCRM Community Edition developed by SalesAgility Ltd.
 * Copyright (C) 2011 - 2019 SalesAgility Ltd.
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 *
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo and "Supercharged by SuiteCRM" logo. If the display of the logos is not
 * reasonably feasible for technical reasons, the Appropriate Legal Notices must
 * display the words "Powered by SugarCRM" and "Supercharged by SuiteCRM".
 */

if (!defined('sugarEntry') || !sugarEntry) {
    die('Not A Valid Entry Point');
}

$mod_strings = array(
    'LBL_ASSIGNED_TO_ID' => 'Id de usuario asignado',
    'LBL_ASSIGNED_TO_NAME' => 'Asignado a',
    'LBL_ID' => 'ID',
    'LBL_DATE_ENTERED' => 'Fecha de Creación',
    'LBL_DATE_MODIFIED' => 'Fecha de Modificación',
    'LBL_MODIFIED' => 'Modificado Por',
    'LBL_MODIFIED_NAME' => 'Modificado por Nombre',
    'LBL_CREATED' => 'Creado por',
    'LBL_DESCRIPTION' => 'Contenido',
    'LBL_HEADER' => 'Encabezado',
    'LBL_FOOTER' => 'Pie de página',
    'LBL_DELETED' => 'Eliminado',
    'LBL_NAME' => 'Nombre',
    'LBL_CREATED_USER' => 'Creado por el Usuario',
    'LBL_MODIFIED_USER' => 'Modificado por el Usuario',
    'LBL_LIST_FORM_TITLE' => 'Lista de Formatos PDF',
    'LBL_MODULE_NAME' => 'Formatos PDF',
    'LBL_MODULE_TITLE' => 'Formatos PDF',
    'LBL_HOMEPAGE_TITLE' => 'Mis Formatos PDF',
    'LNK_NEW_RECORD' => 'Crear Formatos PDF',
    'LNK_LIST' => 'Formatos PDF',
    'LBL_SEARCH_FORM_TITLE' => 'Buscar Formatos PDF',
    'LBL_HISTORY_SUBPANEL_TITLE' => 'Ver Historial',
    'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Actividades',
    'LBL_NEW_FORM_TITLE' => 'Nuevos Formatos PDF',
    'LBL_TYPE' => 'Tipo',
    'LBL_ACTIVE' => 'Activas',
    'LBL_BUTTON_INSERT' => 'Insertar',
    'LBL_WARNING_OVERWRITE' => 'Atención, esta operación sustituirá su trabajo actual',
    'LBL_INSERT_FIELDS' => 'Insertar Campos',

    'LBL_SAMPLE' => 'Cargar Muestra',
    'LBL_PAGE' => 'Página',
    'LBL_PREPARED_FOR' => 'Preparado Para',
    'LBL_PREPARED_BY' => 'Preparado Por',
    'LBL_QUOTE_SAMPLE' => 'Ejemplo de cotización',
    'LBL_INVOICE_SAMPLE' => 'Ejemplo de factura',
    'LBL_ACCOUNT_SAMPLE' => 'Ejemplo de cuenta',
    'LBL_CONTACT_SAMPLE' => 'Ejemplo de contacto',
    'LBL_LEAD_SAMPLE' => 'Ejemplo de cliente potencial',
    'LBL_ANY_STREET' => 'Cualquier Calle',
    'LBL_ANY_TOWN' => 'Cualquier Ciudad',
    'LBL_ANY_WHERE' => 'Cualquier Lugar',

    'LBL_QUOTE_GROUP_SAMPLE' => 'Ejemplo de grupo de cotizaciones',
    'LBL_INVOICE_GROUP_SAMPLE' => 'Ejemplo de grupo de facturas',
    'LBL_MARGIN_LEFT' => 'Margen Izquierdo',
    'LBL_MARGIN_RIGHT' => 'Margen Derecho',
    'LBL_MARGIN_TOP' => 'Margen Superior',
    'LBL_MARGIN_BOTTOM' => 'Margen Inferior',
    'LBL_MARGIN_HEADER' => 'Margen de Encabezado',
    'LBL_MARGIN_FOOTER' => 'Margen de Pie',
    'LBL_EDITVIEW_PANEL1' => 'Márgenes',
    'LBL_DETAILVIEW_PANEL1' => 'Márgenes',
    'LBL_PAGE_SIZE' => 'Tamaño de Página',
    'LBL_ORIENTATION' => 'Orientación',
);
