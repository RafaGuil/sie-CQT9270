<?php
/**
 *
 * SugarCRM Community Edition is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004-2013 SugarCRM Inc.
 *
 * SuiteCRM is an extension to SugarCRM Community Edition developed by SalesAgility Ltd.
 * Copyright (C) 2011 - 2019 SalesAgility Ltd.
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 *
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo and "Supercharged by SuiteCRM" logo. If the display of the logos is not
 * reasonably feasible for technical reasons, the Appropriate Legal Notices must
 * display the words "Powered by SugarCRM" and "Supercharged by SuiteCRM".
 */

if (!defined('sugarEntry') || !sugarEntry) {
    die('Not A Valid Entry Point');
}

$mod_strings = array(
    'LBL_MODULE_NAME' => 'Listas de Público Objetivo',
    'LBL_MODULE_ID' => 'Listas de Público Objetivo',
    'LBL_MODULE_TITLE' => 'Listas de Público Objetivo: Inicio',
    'LBL_SEARCH_FORM_TITLE' => 'Búsqueda de Listas de Público Objetivo',
    'LBL_LIST_FORM_TITLE' => 'Listas de Público Objetivo',
    'LBL_PROSPECT_LIST_NAME' => 'Listas de Público Objetivo:',
    'LBL_NAME' => 'Nombre',
    'LBL_ENTRIES' => 'Total de Entradas',
    'LBL_LIST_PROSPECT_LIST_NAME' => 'Lista de Público Objetivo',
    'LBL_LIST_ENTRIES' => 'Público Objetivo en la Lista',
    'LBL_LIST_DESCRIPTION' => 'Descripción',
    'LBL_LIST_TYPE_NO' => 'Tipo',
    'LBL_LIST_END_DATE' => 'Fecha de Finalización',
    'LBL_DATE_ENTERED' => 'Fecha de Creación',
    'LBL_MARKETING_ID' => 'Id de Marketing',
    'LBL_DATE_MODIFIED' => 'Fecha de Modificación',
    'LBL_MODIFIED' => 'Modificado por',
    'LBL_CREATED' => 'Creado por',
    'LBL_ASSIGNED_TO' => 'Asignado a',
    'LBL_DESCRIPTION' => 'Descripción',
    'LNK_NEW_CAMPAIGN' => 'Crear Campaña',
    'LNK_CAMPAIGN_LIST' => 'Campañas',
    'LNK_NEW_PROSPECT_LIST' => 'Crear Lista de Público Objetivo',
    'LNK_PROSPECT_LIST_LIST' => 'Ver Listas de Público Objetivo',
    'LBL_MODIFIED_BY' => 'Modificado por',
    'LBL_CREATED_BY' => 'Creado por',
    'LNK_NEW_PROSPECT' => 'Crear Público Objetivo',
    'LNK_PROSPECT_LIST' => 'Público Objetivo',

    'LBL_CONTACTS_SUBPANEL_TITLE' => 'Contactos',
    'LBL_LEADS_SUBPANEL_TITLE' => 'Clientes Potenciales',
    'LBL_PROSPECTS_SUBPANEL_TITLE' => 'Público Objetivo',
    'LBL_ACCOUNTS_SUBPANEL_TITLE' => 'Cuentas',
    'LBL_COPY_PREFIX' => 'Copia de',
    'LBL_USERS_SUBPANEL_TITLE' => 'Usuarios',
    'LBL_TYPE' => 'Tipo',
    'LBL_LIST_TYPE' => 'Tipo',
    'LBL_LIST_TYPE_LIST_NAME' => 'Tipo',
    'LBL_NEW_FORM_TITLE' => 'Nueva Lista de Público Objetivo',
    'LBL_MARKETING_NAME' => 'Nombre de Marketing',
    'LBL_DOMAIN_NAME' => 'Nombre de Dominio',
    'LBL_DOMAIN' => 'No hay correos para este dominio',
    'LBL_LIST_PROSPECTLIST_NAME' => 'Nombre',

    'LBL_EMAIL_MARKETING' => 'Marketing por Email',

    'LBL_ASCENDING' => 'Ascendente',
    'LBL_DESCENDING' => 'Descendente',
);
